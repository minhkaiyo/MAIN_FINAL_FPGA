// mdio_init.v
// Module cấu hình MDIO: Tắt quảng bá Gigabit (1000Mbps) để ép Laptop nhận 100Mbps (MII)
// Ghi cho cả 2 địa chỉ PHY (0x10 và 0x11) để bao trùm cả ENET0 và ENET1.

module mdio_init (
    input  wire clk,         // Khuyên dùng 50MHz
    input  wire rst_n,       // Khởi động khi rst_n = 1
    
    output reg  mdc,         // Xung nhịp cho MDIO (~1MHz)
    output reg  mdio_out,    // Dữ liệu truyền ra
    output reg  mdio_en,     // 1: Xuất dữ liệu, 0: Thả nổi (Z)
    output reg  done         // 1: Đã cấu hình xong
);

    // Lệnh cho PHY 0x10 (ENET0)
    wire [31:0] cmd1 = {2'b01, 2'b01, 5'b10000, 5'b01001, 2'b10, 16'h0000}; // Reg 9 = 0
    wire [31:0] cmd2 = {2'b01, 2'b01, 5'b10000, 5'b00000, 2'b10, 16'h1200}; // Reg 0 = AutoNeg

    // Lệnh cho PHY 0x11 (ENET1)
    wire [31:0] cmd3 = {2'b01, 2'b01, 5'b10001, 5'b01001, 2'b10, 16'h0000}; // Reg 9 = 0
    wire [31:0] cmd4 = {2'b01, 2'b01, 5'b10001, 5'b00000, 2'b10, 16'h1200}; // Reg 0 = AutoNeg

    reg [5:0] step = 0;       
    reg [5:0] bit_cnt = 0;    
    reg [4:0] div_cnt = 0;    
    reg mdc_tick = 0;

    always @(posedge clk) begin
        if (!rst_n) begin
            div_cnt <= 0;
            mdc_tick <= 0;
            mdc <= 0;
        end else begin
            div_cnt <= div_cnt + 1'b1;
            mdc_tick <= (div_cnt == 5'd24); 
            if (div_cnt == 5'd24) div_cnt <= 0;
            if (mdc_tick) mdc <= ~mdc;      
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            step <= 0;
            bit_cnt <= 0;
            mdio_out <= 1;
            mdio_en <= 0;
            done <= 0;
        end else if (mdc_tick && !mdc) begin 
            case (step)
                0: begin mdio_en <= 0; if (bit_cnt < 32) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 1; end end
                // CMD 1
                1: begin mdio_en <= 1; mdio_out <= 1'b1; if (bit_cnt < 31) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 2; end end
                2: begin mdio_out <= cmd1[31 - bit_cnt]; if (bit_cnt < 31) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 3; end end
                3: begin mdio_en <= 0; if (bit_cnt < 31) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 4; end end
                // CMD 2
                4: begin mdio_en <= 1; mdio_out <= 1'b1; if (bit_cnt < 31) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 5; end end
                5: begin mdio_out <= cmd2[31 - bit_cnt]; if (bit_cnt < 31) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 6; end end
                6: begin mdio_en <= 0; if (bit_cnt < 31) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 7; end end
                // CMD 3
                7: begin mdio_en <= 1; mdio_out <= 1'b1; if (bit_cnt < 31) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 8; end end
                8: begin mdio_out <= cmd3[31 - bit_cnt]; if (bit_cnt < 31) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 9; end end
                9: begin mdio_en <= 0; if (bit_cnt < 31) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 10; end end
                // CMD 4
                10: begin mdio_en <= 1; mdio_out <= 1'b1; if (bit_cnt < 31) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 11; end end
                11: begin mdio_out <= cmd4[31 - bit_cnt]; if (bit_cnt < 31) bit_cnt <= bit_cnt + 1'b1; else begin bit_cnt <= 0; step <= 12; end end
                
                12: begin mdio_en <= 0; done <= 1; end
            endcase
        end
    end
endmodule
